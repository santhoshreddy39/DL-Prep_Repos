from pydantic import BaseModel, Field

min_length = 40


class FiscalYearHighlights(BaseModel):
    performance_highlights: str = Field(..., description="Key performance and financial stats over the fiscal year.")
    major_events: str = Field(..., description="Highlight of significant events, acquisitions, or strategic shifts that occurred during the year.")
    challenges_encountered: str = Field(..., description="Challenges the company faced during the year and, if and how they managed or overcame them.")
    # milestone_achievements: str = Field(..., description="Milestones achieved in terms of projects, expansions, or any other notable accomplishments.")


class StrategyOutlookFutureDirection(BaseModel):
    strategic_initiatives: str = Field(..., description="The company's primary objectives and growth strategies for the upcoming years.")
    market_outlook: str = Field(..., description="Insights into the broader market, competitive landscape, and industry trends the company anticipates.")
    product_roadmap: str = Field(..., description="Upcoming launches, expansions, or innovations the company plans to roll out.")

class RiskManagement(BaseModel):
    risk_factors: str = Field(..., description="Primary risks the company acknowledges.")
    risk_mitigation: str = Field(..., description="Strategies for managing these risks.")

class CorporateGovernanceSocialResponsibility(BaseModel):
    board_governance: str = Field(..., description="Details about the company's board composition, governance policies, and any changes in leadership or structure.")
    csr_sustainability: str = Field(..., description="The company's initiatives related to environmental stewardship, community involvement, and ethical practices.")

class InnovationRnD(BaseModel):
    r_and_d_activities: str = Field(..., description="Overview of the company's focus on research and development, major achievements, or breakthroughs.")
    innovation_focus: str = Field(..., description="Mention of new technologies, patents, or areas of research the company is diving into.")
