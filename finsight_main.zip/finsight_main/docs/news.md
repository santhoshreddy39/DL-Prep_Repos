#### FinSight Wins Streamlit LLM Hackathon!!

I'm excited to share some great news with you all. Over the past month, I've been working tirelessly on Finsight, and it's been an incredible journey. Today, I'm thrilled to announce that Finsight has emerged victorious in the LLM Hackathon organized by streamlit, specifically in the LlamaIndex category!


[Read more](https://www.linkedin.com/posts/vishwasgowda217_llm-hackathon-streamlit-activity-7115398433573666816-1y72?utm_source=share&utm_medium=member_desktop)


Stay tuned for more exciting updates from FinSight!
