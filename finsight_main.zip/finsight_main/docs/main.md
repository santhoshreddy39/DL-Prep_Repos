## About the App and Its Features:
Finsight is a cutting-edge AI assistant tailored for portfolio managers, investors, and finance enthusiasts. It streamlines the process of gaining crucial insights and summaries about a company in a user-friendly manner.
 
### [Annual Report Analyzer](https://finsight-report.streamlit.app/Annual_Report_Analyzer): 
Want a deep dive into a company's annual report? Upload the report in PDF format, and Finsight will process and analyze it, offering insights into Fiscal Year Highlights, Strategy Outlook and Future Direction, Risk Management, and Innovation & R&D. 

